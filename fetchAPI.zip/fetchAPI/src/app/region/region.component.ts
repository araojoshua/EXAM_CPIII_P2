import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface Region {
  region_name: string;
}

@Component({
  selector: 'app-region',
  templateUrl: './region.component.html',
  styleUrls: ['./region.component.css']
})
export class RegionComponent implements OnInit {
  regions: Region[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get<Region[]>('https://ncddpdb.dswd.gov.ph/api/ceac/lib_region')
      .subscribe(
        response => {
          this.regions = response;
        },
        error => {
          console.log(error);
        }
      );
  }
}
